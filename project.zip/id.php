<!DOCTYPE html>
<html>
<body>

<?php
echo uniqid();
?>

</body>
</html>